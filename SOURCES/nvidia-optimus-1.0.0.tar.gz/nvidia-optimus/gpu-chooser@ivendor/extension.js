const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const Lang = imports.lang;
const Mainloop = imports.mainloop;
const Util = imports.misc.util;

const Main = imports.ui.main;
const StatusSystem = imports.ui.status.system;
const PopupMenu = imports.ui.popupMenu;
const Me = imports.misc.extensionUtils.getCurrentExtension();
const ConfirmDialog = Me.imports.confirmDialog;
const ExtensionSystem = imports.ui.extensionSystem;

const Extension = new Lang.Class({
    Name: 'GpuChooser.Extension',

    _init: function() {
        var theme = imports.gi.Gtk.IconTheme.get_default();
        let icon_dir = Me.dir.get_child('icons');
        theme.append_search_path(icon_dir.get_path());   

        let gpu_output = '';
        gpu_output = GLib.spawn_command_line_sync("/bin/bash -c 'glxinfo |grep \"OpenGL vendor string:\"|cut -d\" \" -f4'");
        if (gpu_output[0] && (''+gpu_output[1]).trim()=="NVIDIA") {
            this._iconName = "intel-switch";
            this._choice = "Intel";
            this._dialogContent = ConfirmDialog.IntelDialogContent;
        } else {        
            this._iconName = "nvidia-switch";
            this._choice = "Nvidia";
            this._dialogContent = ConfirmDialog.NvidiaDialogContent;
        }
    },

    _doSwitch: function() {
        Util.spawn(['/bin/bash', '-c', "pkexec /usr/sbin/gpu-choice.sh \""+this._choice+"\" && gnome-session-quit --logout --no-prompt"]);
    },

    _onGpuChooseClicked: function() {
        this.systemMenu.menu.itemActivated();
        this._dialog = new ConfirmDialog.ConfirmDialog(this._dialogContent);
        this._dialog.connect('ConfirmedGpuChoose', Lang.bind(this, this._doSwitch));
        this._dialog.open();       
    },

    enable: function() {
        this.systemMenu = Main.panel.statusArea['aggregateMenu']._system;
        this._gpuAction = this.systemMenu._createActionButton(this._iconName, _("GpuChoose"));
        this._gpuActionId = this._gpuAction.connect('clicked', Lang.bind(this, this._onGpuChooseClicked));
        this.systemMenu._actionsItem.actor.insert_child_at_index(this._gpuAction, 1);
    },

    disable: function() {
        if (this._gpuActionId) {
            this._gpuAction.disconnect(this._gpuActionId);
            this._gpuActionId = 0;
        }

        this.systemMenu._actionsItem.actor.remove_child(this._gpuAction);

        if (this._gpuAction) {
            this._gpuAction.destroy();
            this._gpuAction = 0;
        }
    }
});

function init(metadata) {
    var extension = new Extension();
    return (extension);
}

