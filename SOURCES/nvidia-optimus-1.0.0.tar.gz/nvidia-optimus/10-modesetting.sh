#!/bin/bash
/bin/bash /usr/sbin/modesetting.sh bind
