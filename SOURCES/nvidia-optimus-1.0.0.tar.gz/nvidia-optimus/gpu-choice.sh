#!/bin/bash

if [[ -n $1 ]]; then
   CHOICE=$1
else
   exit
fi

if [ $CHOICE = "Intel" ]; then
        echo "Starting Intel..."
        sudo -u gdm dbus-launch gsettings set org.gnome.login-screen logo '/usr/share/pixmaps/fedora-gdm-logo.png'
        systemctl enable bumblebeed
        systemctl start bumblebeed
        rm /etc/X11/xorg.conf.d/20-gpu.conf
        rm /etc/ld.so.conf.d/1-nvidia.conf
        rm /etc/prelink.conf.d/1-nvidia.conf
        ln -s /etc/X11/xorg.conf.d/20-intel.conf.disabled /etc/X11/xorg.conf.d/20-gpu.conf
elif [ $CHOICE = "Nvidia" ]; then
        echo "Starting Nvidia Optimus..."
        sudo -u gdm dbus-launch gsettings set org.gnome.login-screen logo '/usr/share/pixmaps/nvidia-settings.png'
        systemctl disable bumblebeed
        systemctl stop bumblebeed
	rm /etc/X11/xorg.conf.d/20-gpu.conf
	rm /etc/ld.so.conf.d/1-nvidia.conf
	rm /etc/prelink.conf.d/1-nvidia.conf
        ln -s /etc/X11/xorg.conf.d/20-nvidia-optimus.conf.disabled /etc/X11/xorg.conf.d/20-gpu.conf
        ln -s /etc/ld.so.conf.d/nvidia.conf.disabled /etc/ld.so.conf.d/1-nvidia.conf
        ln -s /etc/prelink.conf.d/nvidia.conf.disabled /etc/prelink.conf.d/1-nvidia.conf
else
        exit
fi

echo "GPU_MODE=\"$CHOICE\"" > /etc/default/optimus

nohup bash -c 'sleep 5; ldconfig; systemctl restart gdm' > /dev/null 2>&1 &
