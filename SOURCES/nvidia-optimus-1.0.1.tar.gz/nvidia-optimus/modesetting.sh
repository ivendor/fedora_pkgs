#!/bin/bash

. /etc/default/optimus

if [ "$GPU_MODE" = "Nvidia" ]; then
   xrandr --setprovideroutputsource modesetting NVIDIA-0;
   xrandr --auto;
   
   xrandr --output eDP-1-0 --mode 1920x1080;
else
   xrandr --output eDP1 --mode 1920x1080;
fi

if [ "$1" != "bind" ]; then
   gnome-shell $1 $2 $3 $4
fi

